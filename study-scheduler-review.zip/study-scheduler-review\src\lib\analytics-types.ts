import type { StudyItemKind } from './subjects';

export type AnalyticsSubject = {
  key: string;
  label: string;
  kind: StudyItemKind;
  color: string;
  weight: number;
  targetPercent: number;
  plannedHours: number;
  completedHours: number;
  completionPercent: number;
};

export type CategoryAnalytics = {
  categoryId: number;
  categoryName: string;
  plannedHours: number;
  completedHours: number;
  completionPercent: number;
  daysPerWeek?: number;
  sessionsPerDay?: number;
  startTime?: string;
  endTime?: string;
  subjects: AnalyticsSubject[];
};

export type AnalyticsData = {
  categories: CategoryAnalytics[];
  summary: {
    categoryCount: number;
    plannedHours: number;
    completedHours: number;
    completionPercent: number;
  };
};