'use client';

import Link from 'next/link';
import { useState } from 'react';
import type { FormEvent } from 'react';

type AuthFormProps = {
  mode: 'login' | 'register';
  initialError?: string;
};

export default function AuthForm({ mode, initialError = '' }: AuthFormProps) {
  const isRegister = mode === 'register';
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState(initialError);
  const [isSubmitting, setIsSubmitting] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError('');
    if (isRegister && password !== confirmPassword) {
      setError('ยืนยัน password ไม่ตรงกัน');
      return;
    }

    setIsSubmitting(true);
    try {
      const response = await fetch(`/api/auth/${mode}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password, confirmPassword }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'ดำเนินการไม่สำเร็จ');
      window.location.replace(result.user?.role === 'admin' ? '/admin' : '/');
    } catch (submitError) {
      setError(submitError instanceof Error ? submitError.message : 'ดำเนินการไม่สำเร็จ');
      setIsSubmitting(false);
    }
  }

  return (
    <main className="auth-shell">
      <section className="auth-panel">
        <p className="eyebrow">STUDY PLANNER</p>
        <h1>{isRegister ? 'สร้างบัญชี' : 'เข้าสู่ระบบ'}</h1>
        <p className="auth-intro">
          {isRegister ? 'เริ่มบันทึกแผนอ่านหนังสือของคุณ' : ''}
        </p>

        <form className="auth-form" method="post" action={`/api/auth/${mode}`} onSubmit={submit}>
          <label className="auth-label" htmlFor="username">Username</label>
          <input
            className="auth-input"
            id="username"
            name="username"
            type="text"
            autoComplete="username"
            autoCapitalize="none"
            minLength={3}
            maxLength={32}
            pattern="[a-zA-Z0-9_]{3,32}"
            required
            value={username}
            onChange={(event) => setUsername(event.target.value)}
          />

          <label className="auth-label" htmlFor="password">Password</label>
          <input
            className="auth-input"
            id="password"
            name="password"
            type="password"
            autoComplete={isRegister ? 'new-password' : 'current-password'}
            minLength={8}
            maxLength={128}
            required
            value={password}
            onChange={(event) => setPassword(event.target.value)}
          />

          {isRegister && (
            <>
              <label className="auth-label" htmlFor="confirm-password">ยืนยัน Password</label>
              <input
                className="auth-input"
                id="confirm-password"
                name="confirmPassword"
                type="password"
                autoComplete="new-password"
                minLength={8}
                maxLength={128}
                required
                value={confirmPassword}
                onChange={(event) => setConfirmPassword(event.target.value)}
              />
            </>
          )}

          {error && <p className="auth-error" role="alert">{error}</p>}
          <button className="auth-submit" type="submit" disabled={isSubmitting}>
            {isSubmitting ? 'กำลังตรวจสอบ...' : isRegister ? 'สมัครสมาชิก' : 'เข้าสู่ระบบ'}
          </button>
        </form>

        <p className="auth-switch">
          {isRegister ? 'มีบัญชีแล้ว?' : 'ยังไม่มีบัญชี?'}{' '}
          <Link href={isRegister ? '/login' : '/register'}>
            {isRegister ? 'เข้าสู่ระบบ' : 'สมัครสมาชิก'}
          </Link>
        </p>
      </section>
    </main>
  );
}