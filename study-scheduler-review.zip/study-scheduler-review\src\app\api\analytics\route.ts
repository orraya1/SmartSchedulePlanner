import type { RowDataPacket } from 'mysql2/promise';
import { getSessionUser } from '@/lib/auth';
import { getUserCategories } from '@/lib/categories';
import { ensureDatabase, getPool } from '@/lib/database';
import { getNormalizedWeightPercentages } from '@/lib/weight-percentages';
import type { SubjectPreference } from '@/lib/subjects';

export const runtime = 'nodejs';

type LatestScheduleRow = RowDataPacket & {
  id: number;
  days_per_week: number;
  sessions_per_day: number;
  start_time: string;
  end_time: string;
};

type SubjectHoursRow = RowDataPacket & {
  subject_key: string;
  label: string;
  kind: SubjectPreference['kind'];
  color: string;
  weight: number;
  planned_hours: number;
  completed_hours: number;
};

export async function GET(request: Request): Promise<Response> {
  try {
    const pool = getPool();
    await ensureDatabase(pool);
    const user = await getSessionUser(request, pool);
    if (!user) return Response.json({ error: 'กรุณาเข้าสู่ระบบ' }, { status: 401 });

    const categories = await getUserCategories(pool, user.id);
    const analytics = [];
    for (const category of categories) {
      const [schedules] = await pool.execute<LatestScheduleRow[]>(
        'SELECT id, days_per_week, sessions_per_day, start_time, end_time FROM schedules WHERE user_id = ? AND category_id = ? ORDER BY id DESC LIMIT 1',
        [user.id, category.id],
      );
      const latest = schedules[0];
      if (!latest) {
        analytics.push({
          categoryId: category.id,
          categoryName: category.name,
          plannedHours: 0,
          completedHours: 0,
          completionPercent: 0,
          subjects: [],
        });
        continue;
      }

      const [rows] = await pool.execute<SubjectHoursRow[]>(
        'SELECT subjects.subject_key, subjects.label, subjects.kind, subjects.color, user_subject_preferences.weight, COUNT(study_sessions.id) AS planned_hours, SUM(study_sessions.is_completed) AS completed_hours FROM study_sessions INNER JOIN subjects ON subjects.subject_key = study_sessions.subject_key INNER JOIN user_subject_preferences ON user_subject_preferences.subject_key = subjects.subject_key AND user_subject_preferences.user_id = ? WHERE study_sessions.schedule_id = ? GROUP BY subjects.subject_key, subjects.label, subjects.kind, subjects.color, user_subject_preferences.weight ORDER BY subjects.sort_order, subjects.label',
        [user.id, latest.id],
      );
      const weightShares = getNormalizedWeightPercentages(rows.map((row) => ({ weight: row.weight } as SubjectPreference)));
      const subjects = rows.map((row, index) => {
        const plannedHours = Number(row.planned_hours);
        const completedHours = Number(row.completed_hours);
        return {
          key: row.subject_key,
          label: row.label,
          kind: row.kind,
          color: row.color,
          weight: row.weight,
          targetPercent: weightShares[index] ?? 0,
          plannedHours,
          completedHours,
          completionPercent: plannedHours > 0 ? Math.round((completedHours / plannedHours) * 100) : 0,
        };
      });
      const plannedHours = subjects.reduce((total, subject) => total + subject.plannedHours, 0);
      const completedHours = subjects.reduce((total, subject) => total + subject.completedHours, 0);
      analytics.push({
        categoryId: category.id,
        categoryName: category.name,
        plannedHours,
        completedHours,
        completionPercent: plannedHours > 0 ? Math.round((completedHours / plannedHours) * 100) : 0,
        daysPerWeek: latest.days_per_week,
        sessionsPerDay: latest.sessions_per_day,
        startTime: latest.start_time.slice(0, 5),
        endTime: latest.end_time.slice(0, 5),
        subjects,
      });
    }

    const totals = analytics.reduce((summary, category) => ({
      plannedHours: summary.plannedHours + category.plannedHours,
      completedHours: summary.completedHours + category.completedHours,
    }), { plannedHours: 0, completedHours: 0 });
    return Response.json({
      categories: analytics,
      summary: {
        categoryCount: categories.length,
        plannedHours: totals.plannedHours,
        completedHours: totals.completedHours,
        completionPercent: totals.plannedHours > 0
          ? Math.round((totals.completedHours / totals.plannedHours) * 100)
          : 0,
      },
    });
  } catch (error) {
    console.error('Analytics error:', error instanceof Error ? error.message : 'Unknown error');
    return Response.json({ error: 'โหลด analytics ไม่สำเร็จ' }, { status: 500 });
  }
}