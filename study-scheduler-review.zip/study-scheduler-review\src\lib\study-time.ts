export const STUDY_END_TIME = '22:00';
export const LUNCH_BREAK_START_HOUR = 12;
export const LUNCH_BREAK_END_HOUR = 13;

export function isValidStudyStartTime(value: unknown): value is string {
  return typeof value === 'string' && /^(0[6-9]|1[0-9]|2[01]):00$/.test(value);
}

export function getStudySessionsPerDay(startTime: string): number {
  const startHour = Number(startTime.slice(0, 2));
  const totalHours = 22 - startHour;
  return startHour <= LUNCH_BREAK_START_HOUR ? totalHours - 1 : totalHours;
}

export function getSessionTimeRange(startTime: string, sessionIndex: number): string {
  const initialHour = Number(startTime.slice(0, 2));
  const rawStartHour = initialHour + sessionIndex;
  const startHour = rawStartHour >= LUNCH_BREAK_START_HOUR && initialHour <= LUNCH_BREAK_START_HOUR
    ? rawStartHour + 1
    : rawStartHour;
  const endHour = startHour + 1;
  return `${String(startHour).padStart(2, '0')}:00–${String(endHour).padStart(2, '0')}:00`;
}