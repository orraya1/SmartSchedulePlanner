import type { ResultSetHeader, RowDataPacket } from 'mysql2/promise';
import { getSessionUser } from '@/lib/auth';
import { getOwnedCategory, getUserCategories } from '@/lib/categories';
import { ensureDatabase, getPool } from '@/lib/database';

export const runtime = 'nodejs';

export async function GET(request: Request): Promise<Response> {
  try {
    const pool = getPool();
    await ensureDatabase(pool);
    const user = await getSessionUser(request, pool);
    if (!user) return Response.json({ error: 'กรุณาเข้าสู่ระบบ' }, { status: 401 });
    return Response.json({ categories: await getUserCategories(pool, user.id) });
  } catch (error) {
    console.error('Load categories error:', error instanceof Error ? error.message : 'Unknown error');
    return Response.json({ error: 'โหลดหมวดหมู่ไม่สำเร็จ' }, { status: 500 });
  }
}

export async function POST(request: Request): Promise<Response> {
  try {
    const pool = getPool();
    await ensureDatabase(pool);
    const user = await getSessionUser(request, pool);
    if (!user) return Response.json({ error: 'กรุณาเข้าสู่ระบบ' }, { status: 401 });

    const body: unknown = await request.json();
    const name = body && typeof body === 'object' && 'name' in body && typeof body.name === 'string'
      ? body.name.trim()
      : '';
    if (name.length < 1 || name.length > 60) {
      return Response.json({ error: 'ชื่อหมวดต้องมีความยาว 1–60 ตัวอักษร' }, { status: 400 });
    }

    const [existing] = await pool.execute<RowDataPacket[]>(
      'SELECT id FROM study_categories WHERE user_id = ? AND name = ? LIMIT 1',
      [user.id, name],
    );
    if (existing.length > 0) {
      return Response.json({ error: 'มีหมวดชื่อนี้แล้ว' }, { status: 409 });
    }
    const categories = await getUserCategories(pool, user.id);
    if (categories.length >= 30) {
      return Response.json({ error: 'สร้างหมวดได้สูงสุด 30 หมวด' }, { status: 400 });
    }

    const [result] = await pool.execute<ResultSetHeader>(
      'INSERT INTO study_categories (user_id, name) VALUES (?, ?)',
      [user.id, name],
    );
    return Response.json({
      category: { id: result.insertId, name, futureNote: '', lectureNotes: '' },
    }, { status: 201 });
  } catch (error) {
    const code = error && typeof error === 'object' && 'code' in error ? error.code : undefined;
    if (code === 'ER_DUP_ENTRY') return Response.json({ error: 'มีหมวดชื่อนี้แล้ว' }, { status: 409 });
    console.error('Create category error:', error instanceof Error ? error.message : 'Unknown error');
    return Response.json({ error: 'สร้างหมวดไม่สำเร็จ' }, { status: 500 });
  }
}

export async function PATCH(request: Request): Promise<Response> {
  try {
    const pool = getPool();
    await ensureDatabase(pool);
    const user = await getSessionUser(request, pool);
    if (!user) return Response.json({ error: 'กรุณาเข้าสู่ระบบ' }, { status: 401 });

    const body: unknown = await request.json();
    if (!body || typeof body !== 'object') {
      return Response.json({ error: 'ข้อมูลโน้ตไม่ถูกต้อง' }, { status: 400 });
    }
    const input = body as Record<string, unknown>;
    const categoryId = Number(input.categoryId);
    const futureNote = typeof input.futureNote === 'string' ? input.futureNote : '';
    const lectureNotes = typeof input.lectureNotes === 'string' ? input.lectureNotes : '';
    if (!Number.isSafeInteger(categoryId) || categoryId < 1
      || futureNote.length > 10000 || lectureNotes.length > 10000) {
      return Response.json({ error: 'โน้ตต้องไม่เกิน 10,000 ตัวอักษร' }, { status: 400 });
    }

    if (!(await getOwnedCategory(pool, user.id, categoryId))) {
      return Response.json({ error: 'ไม่พบหมวดนี้' }, { status: 404 });
    }
    await pool.execute(
      'UPDATE study_categories SET future_note = ?, lecture_notes = ? WHERE id = ? AND user_id = ?',
      [futureNote, lectureNotes, categoryId, user.id],
    );
    const [rows] = await pool.execute<RowDataPacket[]>(
      "SELECT id, name, COALESCE(future_note, '') AS futureNote, COALESCE(lecture_notes, '') AS lectureNotes FROM study_categories WHERE id = ? AND user_id = ? LIMIT 1",
      [categoryId, user.id],
    );
    return Response.json({ category: rows[0] });
  } catch (error) {
    console.error('Save category notes error:', error instanceof Error ? error.message : 'Unknown error');
    return Response.json({ error: 'บันทึกโน้ตไม่สำเร็จ' }, { status: 500 });
  }
}

export async function DELETE(request: Request): Promise<Response> {
  let connection;
  try {
    const pool = getPool();
    await ensureDatabase(pool);
    const user = await getSessionUser(request, pool);
    if (!user) return Response.json({ error: 'กรุณาเข้าสู่ระบบ' }, { status: 401 });

    const body: unknown = await request.json();
    const categoryId = body && typeof body === 'object' && 'categoryId' in body
      ? Number(body.categoryId)
      : Number.NaN;
    if (!Number.isSafeInteger(categoryId) || categoryId < 1) {
      return Response.json({ error: 'เลือกหมวดที่ต้องการลบ' }, { status: 400 });
    }

    const [ownedCategory] = await pool.execute<RowDataPacket[]>(
      'SELECT id FROM study_categories WHERE id = ? AND user_id = ? LIMIT 1',
      [categoryId, user.id],
    );
    if (!ownedCategory[0]) return Response.json({ error: 'ไม่พบหมวดนี้' }, { status: 404 });

    connection = await pool.getConnection();
    await connection.beginTransaction();
    await connection.execute(
      'DELETE FROM study_sessions WHERE schedule_id IN (SELECT id FROM schedules WHERE user_id = ? AND category_id = ?)',
      [user.id, categoryId],
    );
    await connection.execute(
      'DELETE FROM schedules WHERE user_id = ? AND category_id = ?',
      [user.id, categoryId],
    );
    await connection.execute(
      'DELETE preferences FROM user_subject_preferences preferences INNER JOIN subjects ON subjects.subject_key = preferences.subject_key WHERE preferences.user_id = ? AND subjects.user_id = ? AND subjects.category_id = ?',
      [user.id, user.id, categoryId],
    );
    await connection.execute(
      'DELETE FROM subjects WHERE user_id = ? AND category_id = ?',
      [user.id, categoryId],
    );
    await connection.execute(
      'DELETE FROM study_categories WHERE id = ? AND user_id = ?',
      [categoryId, user.id],
    );
    await connection.commit();
    return Response.json({ categories: await getUserCategories(pool, user.id) });
  } catch (error) {
    if (connection) {
      try {
        await connection.rollback();
      } catch {
        console.error('Delete category transaction rollback failed');
      }
    }
    console.error('Delete category error:', error instanceof Error ? error.message : 'Unknown error');
    return Response.json({ error: 'ลบหมวดไม่สำเร็จ' }, { status: 500 });
  } finally {
    connection?.release();
  }
}