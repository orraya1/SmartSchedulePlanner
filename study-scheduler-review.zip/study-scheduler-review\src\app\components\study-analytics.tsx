'use client';

import AppNavigation from './app-navigation';
import { useAnalyticsData } from './use-analytics-data';

export default function StudyAnalytics({ username }: { username: string }) {
  const { data, error, isLoading } = useAnalyticsData();
  const maximumHours = Math.max(1, ...(data?.categories.map((category) => category.plannedHours) ?? [0]));

  return (
    <main className="app-shell overview-shell">
      <AppNavigation activePage="analytics" username={username} />
      <header className="page-header overview-header">
        <div>
          <p className="eyebrow">STUDY PERFORMANCE</p>
          <h1>Analytics</h1>
        </div>
        {data && <p className="analytics-total">{data.summary.completedHours}/{data.summary.plannedHours} ชั่วโมง · {data.summary.completionPercent}%</p>}
      </header>

      {error && <p className="dashboard-error" role="alert">{error}</p>}
      <section className="analytics-section" aria-labelledby="hours-chart-title">
        <div className="section-heading">
          <h2 id="hours-chart-title">ชั่วโมงตามแผน GA เทียบกับอ่านเสร็จ</h2>
          <div className="chart-legend" aria-label="คำอธิบายกราฟ">
            <span><i className="legend-planned" /> ตามแผน</span>
            <span><i className="legend-completed" /> อ่านเสร็จ</span>
          </div>
        </div>
        {isLoading ? (
          <p className="overview-empty">กำลังโหลดข้อมูล...</p>
        ) : data?.categories.length ? (
          <div className="hours-chart" role="img" aria-label="กราฟชั่วโมงอ่านตามแผนและอ่านเสร็จแยกตามหมวด">
            {data.categories.map((category) => (
              <div className="hours-chart-row" key={category.categoryId}>
                <div className="hours-chart-label">
                  <strong>{category.categoryName}</strong>
                  <span>{category.completedHours}/{category.plannedHours} ชม. · {category.completionPercent}%</span>
                </div>
                <div className="hours-chart-bars">
                  <div className="hours-bar-track">
                    <span className="hours-bar hours-bar-planned" style={{ width: `${(category.plannedHours / maximumHours) * 100}%` }} />
                  </div>
                  <div className="hours-bar-track">
                    <span className="hours-bar hours-bar-completed" style={{ width: `${(category.completedHours / maximumHours) * 100}%` }} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="overview-empty">ยังไม่มีตารางที่สร้างด้วย Genetic Algorithm</p>
        )}
      </section>

      {data?.categories.some((category) => category.subjects.length > 0) && (
        <section className="analytics-section" aria-labelledby="subject-progress-title">
          <div className="section-heading">
            <h2 id="subject-progress-title">ความคืบหน้าแยกตามกิจกรรม</h2>
          </div>
          <div className="activity-analytics-list">
            {data.categories.filter((category) => category.subjects.length > 0).map((category) => (
              <section className="activity-analytics-card" key={category.categoryId}>
                <div className="activity-analytics-header">
                  <div>
                    <h3>{category.categoryName}</h3>
                    <span>
                      {category.subjects.filter((subject) => subject.kind === 'subject').length} วิชา · {category.subjects.filter((subject) => subject.kind === 'activity').length} กิจกรรม · {category.completedHours}/{category.plannedHours} ชม. · เสร็จ {category.completionPercent}%
                    </span>
                  </div>
                </div>
                {(['subject', 'activity'] as const).map((kind) => {
                  const items = category.subjects.filter((subject) => subject.kind === kind);
                  if (items.length === 0) return null;
                  return (
                    <div className="activity-kind-group" key={kind}>
                      <div className="activity-kind-heading">
                        <h4>{kind === 'activity' ? 'กิจกรรม' : 'รายวิชา'}</h4>
                        <span>{items.length} รายการ</span>
                      </div>
                      <div className="subject-analytics-list">
                        {items.map((subject) => (
                          <div className="subject-analytics-row" key={`${category.categoryId}-${subject.key}`}>
                            <div className="subject-analytics-name">
                              <span className="subject-mark" style={{ '--subject-color': subject.color } as React.CSSProperties} />
                              <span><strong>{subject.label}</strong><small>{kind === 'activity' ? 'กิจกรรม' : 'วิชา'}</small></span>
                            </div>
                            <span>เป้า {subject.targetPercent}%</span>
                            <span>{subject.completedHours}/{subject.plannedHours} ชม.</span>
                            <div className="overview-progress" aria-label={`อ่านเสร็จ ${subject.completionPercent}%`}>
                              <span style={{ width: `${subject.completionPercent}%` }} />
                            </div>
                            <strong className="overview-progress-value">{subject.completionPercent}%</strong>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </section>
            ))}
          </div>
        </section>
      )}
    </main>
  );
}