import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ตารางอ่านหนังสือ | Study Planner",
  description: "จัดตารางอ่านหนังสือมัธยมศึกษาด้วย Genetic Algorithm",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="th">
      <body>{children}</body>
    </html>
  );
}
