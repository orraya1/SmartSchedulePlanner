'use client';

import { useEffect, useState } from 'react';
import type { AnalyticsData } from '@/lib/analytics-types';

export function useAnalyticsData() {
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function loadAnalytics() {
      setIsLoading(true);
      setError('');
      try {
        const response = await fetch('/api/analytics', { cache: 'no-store' });
        if (response.status === 401) {
          window.location.replace('/login');
          return;
        }
        const result = await response.json();
        if (!response.ok) throw new Error(result.error || 'โหลด analytics ไม่สำเร็จ');
        setData(result);
      } catch (requestError: unknown) {
        setError(requestError instanceof Error ? requestError.message : 'โหลด analytics ไม่สำเร็จ');
      } finally {
        setIsLoading(false);
      }
    }

    void loadAnalytics();
    const handleFocus = () => void loadAnalytics();
    window.addEventListener('focus', handleFocus);
    return () => window.removeEventListener('focus', handleFocus);
  }, []);

  return { data, error, isLoading };
}