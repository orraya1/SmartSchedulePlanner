import { randomBytes } from 'node:crypto';
import type { RowDataPacket } from 'mysql2/promise';
import { getSessionUser } from '@/lib/auth';
import { getOwnedCategory } from '@/lib/categories';
import { ensureDatabase, getPool, getUserSubjectLists } from '@/lib/database';
import type { StudyItemKind } from '@/lib/subjects';

export const runtime = 'nodejs';

export async function POST(request: Request): Promise<Response> {
  try {
    const pool = getPool();
    await ensureDatabase(pool);
    const user = await getSessionUser(request, pool);
    if (!user) return Response.json({ error: 'กรุณาเข้าสู่ระบบ' }, { status: 401 });

    const body: unknown = await request.json();
    if (!body || typeof body !== 'object') {
      return Response.json({ error: 'ข้อมูลวิชาไม่ถูกต้อง' }, { status: 400 });
    }

    const input = body as Record<string, unknown>;
    const categoryId = Number(input.categoryId);
    if (!Number.isSafeInteger(categoryId) || categoryId < 1
      || !(await getOwnedCategory(pool, user.id, categoryId))) {
      return Response.json({ error: 'กรุณาเลือกหมวดที่เป็นของบัญชีคุณ' }, { status: 400 });
    }
    let subjectKey: string;
    let defaultWeight = 20;
    if (typeof input.subjectKey === 'string') {
      const [rows] = await pool.execute<RowDataPacket[]>(
        'SELECT subject_key, weight FROM subjects WHERE subject_key = ? AND (user_id IS NULL OR user_id = ?) LIMIT 1',
        [input.subjectKey, user.id],
      );
      if (!rows[0]) return Response.json({ error: 'ไม่พบวิชาที่เลือก' }, { status: 400 });
      subjectKey = rows[0].subject_key as string;
      defaultWeight = rows[0].weight as number;
    } else {
      const label = typeof input.label === 'string' ? input.label.trim() : '';
      const kind = input.kind;
      if (label.length < 1 || label.length > 60 || (kind !== 'subject' && kind !== 'activity')) {
        return Response.json({ error: 'กรอกชื่อรายการ 1–60 ตัวอักษรและเลือกประเภทให้ถูกต้อง' }, { status: 400 });
      }

      const [customItems] = await pool.execute<RowDataPacket[]>(
        'SELECT subject_key FROM subjects WHERE user_id = ? AND category_id = ? AND label = ? AND kind = ? LIMIT 1',
        [user.id, categoryId, label, kind],
      );
      if (customItems[0]) {
        subjectKey = customItems[0].subject_key as string;
      } else {
        const [counts] = await pool.execute<RowDataPacket[]>(
          'SELECT COUNT(*) AS item_count FROM subjects WHERE user_id = ? AND category_id = ?',
          [user.id, categoryId],
        );
        if (Number(counts[0].item_count) >= 50) {
          return Response.json({ error: 'เพิ่มรายการกำหนดเองได้สูงสุด 50 รายการ' }, { status: 400 });
        }
        subjectKey = `custom_${randomBytes(12).toString('hex')}`;
        const color = kind === 'activity' ? '#bd7950' : '#5479a8';
        await pool.execute(
          'INSERT INTO subjects (subject_key, user_id, category_id, kind, label, color, weight, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, 100)',
          [subjectKey, user.id, categoryId, kind as StudyItemKind, label, color, defaultWeight],
        );
      }
    }

    await pool.execute(
      'INSERT INTO user_subject_preferences (user_id, subject_key, weight, is_added) VALUES (?, ?, ?, 1) ON DUPLICATE KEY UPDATE is_added = 1',
      [user.id, subjectKey, defaultWeight],
    );
    return Response.json(await getUserSubjectLists(pool, user.id, categoryId));
  } catch (error) {
    console.error('Add subject error:', error instanceof Error ? error.message : 'Unknown error');
    return Response.json({ error: 'เพิ่มวิชาไม่สำเร็จ ตรวจสอบการเชื่อมต่อฐานข้อมูล' }, { status: 500 });
  }
}

export async function DELETE(request: Request): Promise<Response> {
  try {
    const pool = getPool();
    await ensureDatabase(pool);
    const user = await getSessionUser(request, pool);
    if (!user) return Response.json({ error: 'กรุณาเข้าสู่ระบบ' }, { status: 401 });

    const body: unknown = await request.json();
    const subjectKey = body && typeof body === 'object' && 'subjectKey' in body
      ? body.subjectKey
      : undefined;
    const categoryId = body && typeof body === 'object' && 'categoryId' in body
      ? Number(body.categoryId)
      : Number.NaN;
    if (typeof subjectKey !== 'string' || !Number.isSafeInteger(categoryId)
      || !(await getOwnedCategory(pool, user.id, categoryId))) {
      return Response.json({ error: 'ไม่พบวิชาที่เลือก' }, { status: 400 });
    }

    await pool.execute(
      'UPDATE user_subject_preferences preferences INNER JOIN subjects ON subjects.subject_key = preferences.subject_key SET preferences.is_added = 0 WHERE preferences.user_id = ? AND preferences.subject_key = ? AND subjects.user_id = ? AND subjects.category_id = ?',
      [user.id, subjectKey, user.id, categoryId],
    );

    // Removing an item from Study Plan must also remove its existing sessions.
    // Otherwise Analytics would still count those old sessions as planned hours.
    await pool.execute(
      'DELETE study_sessions FROM study_sessions INNER JOIN schedules ON schedules.id = study_sessions.schedule_id WHERE schedules.user_id = ? AND schedules.category_id = ? AND study_sessions.subject_key = ?',
      [user.id, categoryId, subjectKey],
    );

    // Remove schedules that no longer contain any study sessions so Analytics
    // cannot keep reporting an empty/stale schedule for this category.
    await pool.execute(
      'DELETE FROM schedules WHERE user_id = ? AND category_id = ? AND NOT EXISTS (SELECT 1 FROM study_sessions WHERE study_sessions.schedule_id = schedules.id)',
      [user.id, categoryId],
    );

    return Response.json(await getUserSubjectLists(pool, user.id, categoryId));
  } catch (error) {
    console.error('Remove subject error:', error instanceof Error ? error.message : 'Unknown error');
    return Response.json({ error: 'นำวิชาออกไม่สำเร็จ ตรวจสอบการเชื่อมต่อฐานข้อมูล' }, { status: 500 });
  }
}