import StudyPlanner from '@/app/components/study-planner';
import { requireAuthenticatedUser } from '@/lib/auth-page';

export const dynamic = 'force-dynamic';

export default async function StudyPlanPage() {
  const user = await requireAuthenticatedUser();
  return <StudyPlanner username={user.username} />;
}