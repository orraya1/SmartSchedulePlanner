export type StudyItemKind = 'subject' | 'activity';
export const PRIORITY_WEIGHT_LEVELS = [10, 20, 25, 30] as const;
export type PriorityWeight = typeof PRIORITY_WEIGHT_LEVELS[number];

export function isPriorityWeight(value: unknown): value is PriorityWeight {
  return PRIORITY_WEIGHT_LEVELS.some((level) => level === value);
}

export type SubjectPreference = {
  key: string;
  label: string;
  color: string;
  weight: PriorityWeight;
  kind: StudyItemKind;
};

export const defaultSubjects: SubjectPreference[] = [
  { key: 'english', label: 'อังกฤษ', color: '#3979a8', weight: 10, kind: 'subject' },
  { key: 'physics', label: 'ฟิสิกส์', color: '#d07842', weight: 20, kind: 'subject' },
  { key: 'math', label: 'คณิต', color: '#548b68', weight: 25, kind: 'subject' },
  { key: 'biology', label: 'ชีวะ', color: '#a25d74', weight: 30, kind: 'subject' },
];