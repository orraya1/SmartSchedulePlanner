import { deleteSession, expiredSessionCookie } from '@/lib/auth';
import { getPool } from '@/lib/database';

export const runtime = 'nodejs';

export async function POST(request: Request): Promise<Response> {
  try {
    await deleteSession(request, getPool());
  } catch (error) {
    console.error('Logout error:', error instanceof Error ? error.message : 'Unknown error');
  }
  return new Response(null, {
    status: 303,
    headers: {
      Location: new URL('/login', request.url).toString(),
      'Set-Cookie': expiredSessionCookie(),
    },
  });
}