'use client';

import Link from 'next/link';

export type AppPage = 'home' | 'study-plan' | 'analytics';

const links: Array<{ href: string; id: AppPage; label: string }> = [
  { href: '/', id: 'home', label: 'Home' },
  { href: '/study-plan', id: 'study-plan', label: 'Study Plan' },
  { href: '/analytics', id: 'analytics', label: 'Analytics' },
];

export default function AppNavigation({
  activePage,
  username,
}: {
  activePage: AppPage;
  username: string;
}) {
  return (
    <div className="app-topbar">
      <nav className="app-navigation" aria-label="เมนูหลัก">
        {links.map((link) => (
          <Link
            className={`app-navigation-link ${activePage === link.id ? 'app-navigation-active' : ''}`}
            href={link.href}
            key={link.id}
            aria-current={activePage === link.id ? 'page' : undefined}
          >
            {link.label}
          </Link>
        ))}
      </nav>
      <div className="topbar-account">
        <span className="signed-in-user">{username}</span>
        <Link className="logout-link" href="/logout">ออกจากระบบ</Link>
      </div>
    </div>
  );
}