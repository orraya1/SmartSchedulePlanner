import mysql, { type Pool, type PoolConnection, type RowDataPacket } from 'mysql2/promise';
import type { SubjectPreference } from './subjects';

declare global { var studyPlannerPool: Pool | undefined; }

export function getPool(): Pool {
  if (!globalThis.studyPlannerPool) {
    globalThis.studyPlannerPool = mysql.createPool({
      host: process.env.MYSQL_HOST ?? process.env.DB_HOST,
      port: Number(process.env.MYSQL_PORT ?? process.env.DB_PORT ?? 3306),
      user: process.env.MYSQL_USER ?? process.env.DB_USER,
      password: process.env.MYSQL_PASSWORD ?? process.env.DB_PASSWORD,
      database: process.env.MYSQL_DATABASE ?? process.env.DB_NAME ?? 'study_scheduler',
      waitForConnections: true,
      connectionLimit: 10,
      charset: 'utf8mb4',
    });
  }
  return globalThis.studyPlannerPool;
}

export async function ensureDatabase(connection: Pool | PoolConnection): Promise<void> {
  await connection.execute(`CREATE TABLE IF NOT EXISTS users (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(32) NOT NULL UNIQUE, password_hash VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') NOT NULL DEFAULT 'user', active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);
  const [role] = await connection.query<RowDataPacket[]>("SHOW COLUMNS FROM users LIKE 'role'");
  if (!role.length) await connection.execute("ALTER TABLE users ADD COLUMN role ENUM('user', 'admin') NOT NULL DEFAULT 'user' AFTER password_hash");
  const [active] = await connection.query<RowDataPacket[]>("SHOW COLUMNS FROM users LIKE 'active'");
  if (!active.length) await connection.execute("ALTER TABLE users ADD COLUMN active TINYINT(1) NOT NULL DEFAULT 1 AFTER role");
  await connection.execute(`CREATE TABLE IF NOT EXISTS study_categories (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NOT NULL,
    name VARCHAR(60) NOT NULL, future_note TEXT NULL, lecture_notes TEXT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_user_category (user_id, name),
    CONSTRAINT fk_category_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await connection.execute(`CREATE TABLE IF NOT EXISTS subjects (
    subject_key VARCHAR(32) PRIMARY KEY, user_id BIGINT UNSIGNED NULL, category_id BIGINT UNSIGNED NULL,
    kind VARCHAR(16) NOT NULL DEFAULT 'subject', label VARCHAR(80) NOT NULL,
    color VARCHAR(7) NOT NULL DEFAULT '#64756d', weight TINYINT UNSIGNED NOT NULL DEFAULT 20,
    sort_order TINYINT UNSIGNED NOT NULL, KEY idx_subject_owner (user_id), KEY idx_subject_category (category_id),
    CONSTRAINT fk_subject_owner FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_subject_category FOREIGN KEY (category_id) REFERENCES study_categories(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await connection.execute(`CREATE TABLE IF NOT EXISTS user_subject_preferences (
    user_id BIGINT UNSIGNED NOT NULL, subject_key VARCHAR(32) NOT NULL,
    weight TINYINT UNSIGNED NOT NULL DEFAULT 20, is_added TINYINT(1) NOT NULL DEFAULT 0,
    PRIMARY KEY (user_id, subject_key),
    CONSTRAINT fk_preference_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_preference_subject FOREIGN KEY (subject_key) REFERENCES subjects(subject_key)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await connection.execute(`CREATE TABLE IF NOT EXISTS schedules (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NULL,
    category_id BIGINT UNSIGNED NULL, days_per_week TINYINT UNSIGNED NOT NULL,
    sessions_per_day TINYINT UNSIGNED NOT NULL, start_time TIME NOT NULL DEFAULT '20:00:00',
    end_time TIME NOT NULL DEFAULT '22:00:00', created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_schedules_user (user_id), KEY idx_schedule_category (category_id),
    CONSTRAINT fk_schedule_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_schedule_category FOREIGN KEY (category_id) REFERENCES study_categories(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);
  await connection.execute(`CREATE TABLE IF NOT EXISTS auth_sessions (
    token_hash CHAR(64) NOT NULL PRIMARY KEY, user_id BIGINT UNSIGNED NOT NULL,
    expires_at DATETIME NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_auth_sessions_user (user_id),
    CONSTRAINT fk_auth_session_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await connection.execute(`CREATE TABLE IF NOT EXISTS study_sessions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, schedule_id BIGINT UNSIGNED NOT NULL,
    day_index TINYINT UNSIGNED NOT NULL, session_index TINYINT UNSIGNED NOT NULL,
    subject_key VARCHAR(32) NOT NULL, is_completed TINYINT(1) NOT NULL DEFAULT 0,
    UNIQUE KEY one_subject_per_slot (schedule_id, day_index, session_index),
    CONSTRAINT fk_session_schedule FOREIGN KEY (schedule_id) REFERENCES schedules(id) ON DELETE CASCADE,
    CONSTRAINT fk_session_subject FOREIGN KEY (subject_key) REFERENCES subjects(subject_key)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await connection.execute("INSERT IGNORE INTO subjects (subject_key, kind, label, color, weight, sort_order) VALUES ('english','subject','อังกฤษ','#3979a8',10,0),('physics','subject','ฟิสิกส์','#d07842',20,1),('math','subject','คณิต','#548b68',25,2),('biology','subject','ชีวะ','#a25d74',30,3)");
}

type SubjectRow = RowDataPacket & {
  subject_key: string; label: string; color: string; weight: number; kind: 'subject' | 'activity';
};

export async function getUserSubjectLists(
  connection: Pool | PoolConnection, userId: number, categoryId: number,
): Promise<{ subjects: SubjectPreference[]; availableSubjects: SubjectPreference[] }> {
  const [rows] = await connection.execute<SubjectRow[]>(
    `SELECT s.subject_key, s.label, s.color, p.weight, s.kind
     FROM subjects s INNER JOIN user_subject_preferences p ON p.subject_key = s.subject_key AND p.user_id = ?
     WHERE p.is_added = 1 AND (s.user_id IS NULL OR s.user_id = ?) AND (s.category_id IS NULL OR s.category_id = ?)
     ORDER BY s.sort_order, s.label`, [userId, userId, categoryId],
  );
  const [available] = await connection.execute<SubjectRow[]>(
    `SELECT s.subject_key, s.label, s.color, s.weight, s.kind FROM subjects s
     LEFT JOIN user_subject_preferences p ON p.subject_key = s.subject_key AND p.user_id = ?
     WHERE (s.user_id IS NULL OR s.user_id = ?) AND (s.category_id IS NULL OR s.category_id = ?)
       AND COALESCE(p.is_added, 0) = 0 ORDER BY s.sort_order, s.label`, [userId, userId, categoryId],
  );
  const map = (items: SubjectRow[]): SubjectPreference[] => items.map((item) => ({
    key: item.subject_key, label: item.label, color: item.color,
    weight: Number(item.weight) as SubjectPreference['weight'], kind: item.kind,
  }));
  return { subjects: map(rows), availableSubjects: map(available) };
}
