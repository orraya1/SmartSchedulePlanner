import type { SubjectPreference } from './subjects';

type Chromosome = string[];

function createSeededRandom(seed: string): () => number {
  let state = 2166136261;
  for (let index = 0; index < seed.length; index += 1) {
    state = Math.imul(state ^ seed.charCodeAt(index), 16777619);
  }

  return () => {
    state = (state + 0x6d2b79f5) | 0;
    let value = state;
    value = Math.imul(value ^ (value >>> 15), value | 1);
    value ^= value + Math.imul(value ^ (value >>> 7), value | 61);
    return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
  };
}

function calculateTargets(subjects: SubjectPreference[], sessionCount: number): number[] {
  const totalWeight = subjects.reduce((sum, subject) => sum + subject.weight, 0);
  const exactTargets = subjects.map((subject) => (sessionCount * subject.weight) / totalWeight);
  const targets = exactTargets.map(Math.floor);
  const remaining = sessionCount - targets.reduce((sum, count) => sum + count, 0);
  const priority = exactTargets
    .map((target, index) => ({ index, remainder: target - Math.floor(target) }))
    .sort((left, right) => right.remainder - left.remainder);

  for (let index = 0; index < remaining; index += 1) {
    targets[priority[index].index] += 1;
  }
  return targets;
}

function shuffled<T>(items: T[], random: () => number): T[] {
  const result = [...items];
  for (let index = result.length - 1; index > 0; index -= 1) {
    const otherIndex = Math.floor(random() * (index + 1));
    [result[index], result[otherIndex]] = [result[otherIndex], result[index]];
  }
  return result;
}

function fitness(
  chromosome: Chromosome,
  subjects: SubjectPreference[],
  targets: number[],
  daysPerWeek: number,
  sessionsPerDay: number,
): number {
  const counts = subjects.map((subject) => chromosome.filter((key) => key === subject.key).length);
  let score = counts.reduce((total, count, index) => {
    const difference = count - targets[index];
    return total + (difference * difference * 8) / Math.max(targets[index], 1);
  }, 0);

  for (let day = 0; day < daysPerWeek; day += 1) {
    const start = day * sessionsPerDay;
    const dailyCounts = new Map<string, number>();
    for (let slot = 0; slot < sessionsPerDay; slot += 1) {
      const subjectKey = chromosome[start + slot];
      dailyCounts.set(subjectKey, (dailyCounts.get(subjectKey) ?? 0) + 1);
      if (slot > 0 && subjectKey === chromosome[start + slot - 1]) score += 3;
      if (day > 0 && subjectKey === chromosome[start - sessionsPerDay + slot]) score += 0.4;
    }
    for (const count of dailyCounts.values()) {
      if (count > 2) score += (count - 2) * 1.5;
    }
  }
  return score;
}

function tournament(population: Chromosome[], scores: number[], random: () => number): Chromosome {
  let bestIndex = Math.floor(random() * population.length);
  for (let contender = 1; contender < 4; contender += 1) {
    const index = Math.floor(random() * population.length);
    if (scores[index] < scores[bestIndex]) bestIndex = index;
  }
  return population[bestIndex];
}

export function createStudySchedule(
  subjects: SubjectPreference[],
  daysPerWeek: number,
  sessionsPerDay: number,
  seed = 'study-planner',
): string[][] {
  const random = createSeededRandom(seed);
  const sessionCount = daysPerWeek * sessionsPerDay;
  const targets = calculateTargets(subjects, sessionCount);
  const seedGenes: string[] = [];
  targets.forEach((count, index) => {
    for (let slot = 0; slot < count; slot += 1) seedGenes.push(subjects[index].key);
  });

  const populationSize = 96;
  const population: Chromosome[] = Array.from({ length: populationSize }, () => shuffled(seedGenes, random));
  let best: Chromosome = population[0];

  for (let generation = 0; generation < 120; generation += 1) {
    const scores = population.map((chromosome) =>
      fitness(chromosome, subjects, targets, daysPerWeek, sessionsPerDay),
    );
    const ranked = population
      .map((chromosome, index) => ({ chromosome, score: scores[index] }))
      .sort((left, right) => left.score - right.score);
    best = ranked[0].chromosome;

    const nextPopulation = ranked.slice(0, 4).map(({ chromosome }) => chromosome);
    while (nextPopulation.length < populationSize) {
      const firstParent = tournament(population, scores, random);
      const secondParent = tournament(population, scores, random);
      const firstCut = Math.floor(random() * sessionCount);
      const secondCut = firstCut + Math.floor(random() * (sessionCount - firstCut));
      const child = firstParent.map((gene, index) =>
        index >= firstCut && index <= secondCut ? secondParent[index] : gene,
      );

      if (random() < 0.22) {
        const mutationCount = random() < 0.2 ? 2 : 1;
        for (let mutation = 0; mutation < mutationCount; mutation += 1) {
          const index = Math.floor(random() * sessionCount);
          child[index] = subjects[Math.floor(random() * subjects.length)].key;
        }
      }
      nextPopulation.push(child);
    }
    population.splice(0, population.length, ...nextPopulation);
  }

  const winner = population.reduce((currentBest, chromosome) =>
    fitness(chromosome, subjects, targets, daysPerWeek, sessionsPerDay)
      < fitness(currentBest, subjects, targets, daysPerWeek, sessionsPerDay)
      ? chromosome
      : currentBest,
  best);

  return Array.from({ length: daysPerWeek }, (_, dayIndex) =>
    winner.slice(dayIndex * sessionsPerDay, (dayIndex + 1) * sessionsPerDay),
  );
}